function mudarCor() {
    const principal = document.querySelector(".principal");
    principal.classList.toggle("azul");
}
document.querySelector("#botao").addEventListener("click", mudarCor);

function mudarCor() {
    const principal = document.querySelector("body");
    principal.style.backgroundColor = `rgb(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)})`;
}